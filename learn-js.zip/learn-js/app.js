// console.log("salam")
// console.error("sifjokktrep;tk['")
// console.warn("kkmflf")

//js
//ts

///variables
//Es5: var 
// var x=10;
// var name="Zahra"

//Es6: const let
// let y=100
// y=400
// console.log(y);

// y="I'm zahra"
// console.log(y);


////////////////functions//////////////
// function sum(x,y){
//     return x+y;   
// }

// let result= sum(10, 30);

// console.log(result);




//if for while
// let x=30
// if (x>30) {
    
// } else {
    
// }

// for (let i = 0; i < 10; i++) {
//     const element = 10;
    
// }


/////////// arrays /////////////
const numbers= [10, 30, 59]

sort ,
min,
average
%3



// console.log(numbers[1]);

// console.log(numbers.length);

// const profile=["Zahra", 33, 1.64];

// console.log(numbers);
// numbers.push(100)
// numbers.unshift(0)
// console.log(numbers);


// numbers.forEach( function(item,index) {
//     numbers[index]=item+2
// } )

// console.log(numbers);

/////////// objects /////////////
// const profile=["Zahra", 33, 1.64];

const profile={ 
    firstName:"Zahra" , 
    lastName:"Yazdani", 
    age:33, 
    height:1.64 
 }

console.log(profile["firstName"]);
console.log(profile.firstName);


/////////// BOM ///////

/////////// DOM /////////


